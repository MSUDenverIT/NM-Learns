<?php

declare(strict_types=1);

namespace Auth0\Quickstart\Contract;

interface QuickstartExample
{
    public function setup(): self;
}
